import React from 'react';
import Main from './views/Main';
import Detail from './views/Detail';
import Update from './components/Update';
import { Router, Link } from '@reach/router';

function App() {
  return (
    <div className="App">
      <Link to={`/products`}>all products</Link>
      <Router>
        <Main path="/products"/>
        <Detail path="/products/:id" />
        <Update path="/products/:id/edit"/>
      </Router>
    </div>
  );
}
export default App;

