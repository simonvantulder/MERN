import React, { useState } from 'react'
// import axios from 'axios';

const ProductForm = (props) => {
    const { initialTitle, initialDesc, initialPrice, Errors, onSubmitProp } = props;

    //keep track of what is being typed via useState hook
    const [title, setTitle] = useState(initialTitle); 
    const [description, setDescription] = useState(initialDesc);
    const [price, setPrice] = useState(initialPrice);

    //handler when the form is submitted
    const onSubmitHandler = e => {
        //prevent default behavior of the submit
        e.preventDefault();
        //pass back to Main for product creation
        onSubmitProp({title: title, description: description, price: price});
    }

    return (
            
        <form onSubmit={onSubmitHandler}>
            {Errors?.title && <p style = {{color:"red"} }> {Errors?.title?.message} </p>}
            <p>
                <label>Title</label><br/>
                <input type="text" onChange={(e)=>setTitle(e.target.value)} value={title}/>
            </p>
            {Errors?.description && <p style = {{color:"red"} }> {Errors?.description?.message} </p>}

            <p>
                <label>Description</label><br/>
                <input type="text" onChange={(e)=>setDescription(e.target.value)} value={description}/>
            </p>
            {Errors?.price && <p style = {{color:"red"} }> {Errors?.price?.message} </p>}
            <p>
                <label>Price</label><br/>
                <input type="number" onChange={(e)=>setPrice(e.target.value)} value={price}/>
            </p>
            <button>Submit Button</button>
        </form>

    )
}

export default ProductForm


