import React, { useEffect, useState } from 'react'
import ProductForm from '../components/ProductForm';
import DeleteButton from '../components/DeleteButton';
import { navigate } from '@reach/router'
import axios from 'axios';


const Update = (props) => {
    // const { initialTitle, initialDesc, initialPrice, onSubmitProp } = props;
    // const initialErrors = [];
    const [errors, setErrors] = useState([])
    const { id } = props;
    const [product, setProduct] = useState({});
    const [loaded, setLoaded] = useState(false);
    const [error, setError] = useState("");

    useEffect(() => {
        axios.get('http://localhost:8000/api/products/' + props.id)
            .then(res => {
                setProduct(res.data.results);
                setLoaded(true);
            })
            .catch(err=>{
                console.log(err); 
                console.log("==============================================================="); 
                setError("These are not the droids you are looking for");});
    }, [props.id])

    const updateProduct = parameter => {
        axios.put('http://localhost:8000/api/products/update/' + id, parameter)
            .then(res => {
                    navigate(`/products/${id}`);
                }
            )
            .catch(err=>{
                console.log(err)
            });
    }
    
    
    if(product + "" === "undefined" ){
        return (
            <div>
                {error}
                <img src= "http://lh5.ggpht.com/_5eY0c1g-zJw/S7QNVUbbCLI/AAAAAAAAAHU/-otmme19A7E/these%20are%20not%20the%20droids%20youre%20looking%20for%20star%20wars%20picture%20funny[6].gif?imgmax=800" alt=" obiwan kenobi" style={{width:"500px", height:"600px"}}/>
            </div>
        )
    }
    
    return (
        <div>
            
            <h1>Update your Product</h1>
            {/* send callback to create new product */}
            {loaded && (<ProductForm onSubmitProp={updateProduct} initialTitle={product?.title} initialDesc={product?.description} initialPrice={product?.price} Errors={errors}/>)}

            <DeleteButton productId={product?._id} successCallback={() => navigate("/products")} />
        </div>
    )

}

export default Update

