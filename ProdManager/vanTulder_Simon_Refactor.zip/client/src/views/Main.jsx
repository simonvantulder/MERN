import React, { useEffect, useState } from 'react'
import ProductList from '../components/ProductList';
import ProductForm from '../components/ProductForm';
import axios from 'axios';

const Main = () => {
    const [products, setProducts] = useState([]);
    const [errors, setErrors] = useState([])
    useEffect(() => {
        axios.get('http://localhost:8000/api/products')
            .then(res => {
                setProducts(res.data.results);
                console.log("_______________")
            });
    }, []);

    const removeFromDom = productId => {
        setProducts(products.filter(product => product._id !== productId));
    }
    const createProduct = product => {
        axios.post('http://localhost:8000/api/products/new', product)
            .then(res=>{
                console.log(res.data.results)
                setProducts([...products, res.data.results]);
                if(res.data.message === "success") {

                } else {
                    setErrors(res.data);
                }
            })
            .catch(err=>{
                console.log(err); 
                // setError("These are not the droids you are looking for");
            });
    }
        return (
            <div>
                <ProductForm onSubmitProp={createProduct} initialTitle="" initialDesc="" initialPrice={0} Errors={errors}/>

                {/* <ProductForm /> */}
                {products.length > 0 && <ProductList products={products} removeFromDom={removeFromDom} />}
            </div>
        )
    
}

export default Main;
