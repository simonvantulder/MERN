import React, { useEffect, useState } from 'react'
import { Link } from "@reach/router";
import { navigate } from '@reach/router'
// import Update from '../components/Update';
import axios from 'axios';

const Detail = props => {
    const [product, setProduct] = useState({})

    // const [loaded, setLoaded] = useState(false)
    useEffect(() => {
        console.log("+++++++++++")
        axios.get(`http://localhost:8000/api/products/${props.id}`)
            .then(res => {
                setProduct(res.data.results);
                // setLoaded(true);
            }
        )
        .catch(err=>{
            console.log(err); 
            // setError("These are not the droids you are looking for");
        });
    }, [props.id])
    const deleteProduct = (productId) => {
        axios.delete(`http://localhost:8000/api/products/delete/${productId}`)
            .then(res => {
                navigate(`/products/`);
            })
            .catch(err=>{
                console.log(err); 
                // setError("These are not the droids you are looking for");
            });
    }
    return (
        <div>
            <p>Title: {product.title}</p>
            <p>Description: {product.description}</p>
            <p>lol you thought this was free...pay: ${product.price} to take this home</p>
            <button onClick={(e) => { deleteProduct(product._id) }}>
                Delete
            </button>
            {/* {loaded && <Update product={product}/>} */}
            <Link to={`/products/${props.id}/edit`}>
                update your {product.title}
            </Link>
            <br/>
            <Link to={`/products/`}>
                back to all products
            </Link>
            
        </div>
    )
}

export default Detail



